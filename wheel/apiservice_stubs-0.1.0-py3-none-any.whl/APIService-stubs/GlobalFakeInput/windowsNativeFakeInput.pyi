from typing import Any
from .enums import BaseWindowsKey
from .baseHandlerFakeInput import BaseHandlerFakeInput

class WindowsNativeFakeInput(BaseHandlerFakeInput):
    @classmethod
    def isPlayingMusic(cls) -> Any: ...
    @classmethod
    def send_key_press(cls, keycode: BaseWindowsKey) -> Any: ...
    @classmethod
    def send_key_release(cls, keycode: BaseWindowsKey) -> Any: ...