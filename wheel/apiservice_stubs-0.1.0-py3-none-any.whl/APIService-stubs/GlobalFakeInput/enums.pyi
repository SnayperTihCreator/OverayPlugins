from typing import Any
from enum import StrEnum, IntEnum

__all__ = ["BaseCommonKey", "BaseWindowsKey", "BaseLinuxKey"]

class BaseCommonKey(StrEnum):
    ...
class BaseWindowsKey(IntEnum):
    ...
class BaseLinuxKey(StrEnum):
    def __new__(cls, keysyms, keycode) -> Any: ...