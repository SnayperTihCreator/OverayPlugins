from typing import Any
import os
import sys
from functools import cache
from pathlib import Path

@cache
def getAppPath() -> Any: ...
@cache
def getAssetsPath() -> Any: ...