from typing import Any
from pathlib import Path

def open_file_manager(path: Path) -> Any: ...