from typing import Any
from ColorControl.theme import Theme
from PySide6.QtGui import QColor, QFont
from attrs import define

@define
class DefaultTheme(Theme):
    baseColor: QColor
    mainTextColor: QColor
    altTextColor: QColor
    font: QFont
    def preInitTheme(self, *args) -> Any: ...
    def postInitTheme(self, *args) -> Any: ...