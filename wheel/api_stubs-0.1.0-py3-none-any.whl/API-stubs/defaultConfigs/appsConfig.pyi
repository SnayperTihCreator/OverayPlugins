from pydantic.dataclasses import dataclass
from .commonConfig import Ports, BaseConfig

@dataclass(frozen=True)
class ChapterWebSockets:
    IN: Ports
    OUT: Ports
@dataclass(frozen=True)
class ChapterShortKey:
    open: str
class ConfigApps(BaseConfig):
    websockets: ChapterWebSockets
    shortkey: ChapterShortKey