from pydantic.dataclasses import dataclass
from pydantic import BaseModel

@dataclass(frozen=True)
class Ports:
    begin: int
    end: int
@dataclass(frozen=True)
class ChapterInfoCreator:
    author: str
@dataclass(frozen=True)
class ChapterNameResource(ChapterInfoCreator):
    name: str
class BaseConfig(BaseModel):
    ...