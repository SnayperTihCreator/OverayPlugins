from pydantic.dataclasses import dataclass
from .commonConfig import ChapterNameResource, BaseConfig

@dataclass(frozen=True)
class ChapterColors:
    base: str
    main_text: str
    alt_text: str
class ConfigTheme(BaseConfig):
    theme: ChapterNameResource
    colors: ChapterColors