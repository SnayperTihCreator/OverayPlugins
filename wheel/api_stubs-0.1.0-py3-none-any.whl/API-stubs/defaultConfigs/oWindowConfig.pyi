from pydantic.dataclasses import dataclass
from .commonConfig import BaseConfig

@dataclass
class ChapterWindow:
    width: int
    height: int
    styleFile: str
    opacity: float
class ConfigWindow(BaseConfig):
    window: ChapterWindow