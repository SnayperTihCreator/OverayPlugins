from pydantic.dataclasses import dataclass
from .commonConfig import BaseConfig

@dataclass
class ChapterWidget:
    styleFile: str
class ConfigWidget(BaseConfig):
    widget: ChapterWidget