from typing import Any
from PySide6.QtWidgets import QFormLayout, QWidget
from API.PlugSetting import PluginSettingTemplate, SettingConfigData

class WindowConfigData(SettingConfigData):
    hasMoved: int
    notClicked: int
class PluginSettingWindow(PluginSettingTemplate):
    formLayout: QFormLayout
    obj: QWidget
    def __init__(self, obj, name_plugin, parent = None) -> Any: ...
    def loader(self) -> Any: ...
    def send_data(self) -> Any: ...