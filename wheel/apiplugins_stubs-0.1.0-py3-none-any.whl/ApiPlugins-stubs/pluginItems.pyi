from typing import Any
from enum import IntEnum
from functools import cached_property
from types import ModuleType
from PySide6.QtWidgets import QWidget
from attrs import define
from Common.core import APIBaseWidget

__all__ = ["PluginItemRole", "PluginItem"]

class PluginItemRole(IntEnum):
    ...
@define
class PluginItem:
    module: ModuleType
    typeModule: str
    active: bool
    namePlugin: str
    countClone: int
    isDuplication: bool
    widget: Any
    def __attrs_post_init__(self) -> Any: ...
    @cached_property
    def save_name(self) -> Any: ...
    @property
    def icon(self) -> Any: ...
    def clone(self) -> Any: ...
    def updateStateItem(self, state) -> Any: ...
    def build(self, parent) -> Any: ...